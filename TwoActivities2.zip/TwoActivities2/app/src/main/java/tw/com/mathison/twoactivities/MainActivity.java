package tw.com.mathison.twoactivities;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "tw.com.mathison.twoactivities.extra.MESSAGE";
    private EditText messageEditText;
    private TextView replyTextView;
    public static final int TEXT_REQUEST = 1;

    ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK){
                        Intent intent = result.getData();
                        String reply = intent.getStringExtra(SecondActivity.EXTRA_REPLY);
                        replyTextView.setText(reply);
                        replyTextView.setVisibility(View.VISIBLE);
                    }
                }
            });


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        messageEditText = findViewById(R.id.editText_main);
        replyTextView = findViewById(R.id.text_reply);
    }

    public void launchSecondActivity(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        String message = messageEditText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, message);
//        startActivity(intent);
//        startActivityForResult(intent, TEXT_REQUEST);
        activityResultLauncher.launch(intent);
    }



//    @Override
//    public void onActivityResult(int requestCode,
//                                 int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == TEXT_REQUEST) {
//            if (resultCode == RESULT_OK) {
//                String reply =
//                        data.getStringExtra(SecondActivity.EXTRA_REPLY);
//                replyTextView.setText(reply);
//                replyTextView.setVisibility(View.VISIBLE);
//            }
//        }
//    }

}