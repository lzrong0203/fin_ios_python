package tw.com.mathison.twoactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private TextView textView;
    public static final String EXTRA_REPLY = "tw.com.mathison.twoactivities.extra.REPLY";
    private EditText replyText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        textView = findViewById(R.id.text_message);
        replyText = findViewById(R.id.editText_second);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        textView.setText(message);
        textView.setVisibility(View.VISIBLE);
    }

    public void returnReply(View view) {
        String replyMessage = replyText.getText().toString();
        Intent replyIntent = new Intent();
        replyIntent.putExtra(EXTRA_REPLY, replyMessage);
        setResult(RESULT_OK, replyIntent);
        Log.d("SecondActivity", "END SECOND!!!!!");
        finish();
    }
}