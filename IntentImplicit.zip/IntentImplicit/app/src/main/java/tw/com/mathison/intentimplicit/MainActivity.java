package tw.com.mathison.intentimplicit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ShareCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText mWebsiteEditText;
    private EditText mLocationEditText;
    private EditText mShareTextEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mWebsiteEditText = findViewById(R.id.website_edittext);
        mLocationEditText = findViewById(R.id.location_edittext);
        mShareTextEditText = findViewById(R.id.share_edittext);
    }

    public void openWebsite(View view) {
        Uri webpage = Uri.parse(mWebsiteEditText.getText().toString());

        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.d("Implicit", getString(R.string.no_handle_message));
        }
    }

    public void openLocation(View view) {
        String loc = mLocationEditText.getText().toString();
        Uri address = Uri.parse("geo:0,0?q=" + loc);

        Intent intent = new Intent(Intent.ACTION_VIEW, address);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.d("Implicit", getString(R.string.no_handle_message));
        }
    }

    public void shareText(View view) {
        String txt = mShareTextEditText.getText().toString();
        String mimeType = "text/plain";
//        ShareCompat.IntentBuilder
//                .from(this)
//                .setType(mimeType)
//                .setChooserTitle("Share Text")
//                .setText(txt)
//                .startChooser();
        ShareCompat.IntentBuilder intentBuilder = new ShareCompat.IntentBuilder(this);
        intentBuilder
                .setType(mimeType)
                .setChooserTitle("Share Text")
                .setText(txt)
                .startChooser();

    }


    public void takePicture(View view) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.d("Implicit", getString(R.string.no_handle_message));
        }
    }
}